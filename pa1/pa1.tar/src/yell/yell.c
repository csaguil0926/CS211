#include <stdio.h>
#include <ctype.h>

int main(int argc, char **argv) {

    char* str = argv[1];
    
    for (int i = 0; str[i]!='\0'; i++){

        int c;

        c=str[i];

        if (islower(c)){
            str[i]=toupper(c);
        }

    }
    
    if (str[0]=='\0'){
        printf ("%s", str);
    } else{
        printf ("%s!!\n", str);
    }
    
    return (0);
  
}